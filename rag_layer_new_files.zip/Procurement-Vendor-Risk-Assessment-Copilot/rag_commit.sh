#!/usr/bin/env bash
# Run from the project root after copying these files in. Creates a branch, commits ONLY the new RAG files, and shows the push command.
set -e
git checkout -b m2/2.x-rag-hybrid-retrieval
git add app/rag scripts/rag_*.py tests/test_rag.py docs/rag.md Makefile.rag .env.rag.example
git status --short
git commit -m "Add Week 2 RAG layer: chunking experiments, hybrid BM25+dense, reranker, cited answers, separate retrieval/answer metrics"
echo "Now: git push -u origin m2/2.x-rag-hybrid-retrieval   (then open a PR into main)"
